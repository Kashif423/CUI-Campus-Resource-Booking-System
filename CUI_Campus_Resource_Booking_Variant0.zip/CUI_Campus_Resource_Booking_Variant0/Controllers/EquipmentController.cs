using CUIResourceBooking.Data;
using CUIResourceBooking.DTOs;
using CUIResourceBooking.Hubs;
using CUIResourceBooking.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace CUIResourceBooking.Controllers;

[ApiController, Authorize, Route("api/equipment")]
public class EquipmentController : ControllerBase {
    private const string CacheKey="equipment_catalogue";
    private readonly AppDbContext db; private readonly IMemoryCache cache; private readonly IHubContext<AvailabilityHub> hub;
    public EquipmentController(AppDbContext db,IMemoryCache cache,IHubContext<AvailabilityHub> hub) { this.db=db;this.cache=cache;this.hub=hub; }

    [HttpGet]
    public async Task<IActionResult> GetAll() {
        if (!cache.TryGetValue(CacheKey,out List<Equipment>? items)) {
            items=await db.Equipment.AsNoTracking().OrderBy(x=>x.Id).ToListAsync();
            cache.Set(CacheKey,items,TimeSpan.FromSeconds(60));
        }
        return Ok(items);
    }
    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetOne(int id) {
        var item=await db.Equipment.FindAsync(id);
        return item==null ? NotFound() : Ok(item);
    }
    [HttpPost, Authorize(Roles="Staff,Admin")]
    public async Task<IActionResult> Create(EquipmentRequest r) {
        if (string.IsNullOrWhiteSpace(r.Name) || r.TotalQuantity<0) return BadRequest(new {message="Invalid equipment details."});
        var item=new Equipment { Name=r.Name.Trim(),Description=r.Description??"",TotalQuantity=r.TotalQuantity,AvailableQuantity=r.TotalQuantity };
        db.Equipment.Add(item); await db.SaveChangesAsync(); cache.Remove(CacheKey); await Broadcast(item);
        return CreatedAtAction(nameof(GetOne),new {id=item.Id},item);
    }
    [HttpPut("{id:int}"), Authorize(Roles="Staff,Admin")]
    public async Task<IActionResult> Update(int id,EquipmentRequest r) {
        var item=await db.Equipment.FindAsync(id); if(item==null)return NotFound();
        var onLoan=item.TotalQuantity-item.AvailableQuantity;
        if(string.IsNullOrWhiteSpace(r.Name)||r.TotalQuantity<onLoan)return Conflict(new {message="Invalid details or total quantity is less than units on loan."});
        item.Name=r.Name.Trim();item.Description=r.Description??"";item.TotalQuantity=r.TotalQuantity;item.AvailableQuantity=r.TotalQuantity-onLoan;
        await db.SaveChangesAsync();cache.Remove(CacheKey);await Broadcast(item);return Ok(item);
    }
    [HttpDelete("{id:int}"), Authorize(Roles="Staff,Admin")]
    public async Task<IActionResult> Delete(int id) {
        var item=await db.Equipment.FindAsync(id);if(item==null)return NotFound();
        if(await db.Loans.AnyAsync(x=>x.EquipmentId==id&&x.Status!="Cancelled"&&x.Status!="Completed"))
            return Conflict(new {message="Cannot delete equipment with active loans."});
        db.Equipment.Remove(item);await db.SaveChangesAsync();cache.Remove(CacheKey);return NoContent();
    }
    private Task Broadcast(Equipment e)=>hub.Clients.All.SendAsync("availabilitychanged",new {
        equipmentId=e.Id,equipmentName=e.Name,availableQuantity=e.AvailableQuantity
    });
}
