using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using CUIResourceBooking.Data;
using CUIResourceBooking.DTOs;
using CUIResourceBooking.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace CUIResourceBooking.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase {
    private readonly AppDbContext db;
    private readonly IConfiguration config;
    public AuthController(AppDbContext db, IConfiguration config) { this.db=db; this.config=config; }

    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterRequest r) {
        if (string.IsNullOrWhiteSpace(r.Name) || string.IsNullOrWhiteSpace(r.Email) ||
            string.IsNullOrWhiteSpace(r.Password) || r.Password.Length < 6)
            return BadRequest(new { message="Enter name, email and password (minimum 6 characters)." });
        var email=r.Email.Trim().ToLowerInvariant();
        if (await db.Users.AnyAsync(x=>x.Email==email))
            return Conflict(new { message="Email is already registered." });
        db.Users.Add(new User { Name=r.Name.Trim(), Email=email,
            PasswordHash=BCrypt.Net.BCrypt.HashPassword(r.Password), Role="Student" });
        await db.SaveChangesAsync();
        return Ok(new { message="Student account created. Please log in." });
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest r) {
        var email=r.Email.Trim().ToLowerInvariant();
        var user=await db.Users.FirstOrDefaultAsync(x=>x.Email==email);
        if (user==null || !BCrypt.Net.BCrypt.Verify(r.Password,user.PasswordHash))
            return Unauthorized(new { message="Invalid email or password." });
        var claims=new[] {
            new Claim(ClaimTypes.NameIdentifier,user.Id.ToString()),
            new Claim(ClaimTypes.Name,user.Name),
            new Claim(ClaimTypes.Email,user.Email),
            new Claim(ClaimTypes.Role,user.Role)
        };
        var key=new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]!));
        var creds=new SigningCredentials(key,SecurityAlgorithms.HmacSha256);
        var token=new JwtSecurityToken(config["Jwt:Issuer"],config["Jwt:Audience"],claims,
            expires:DateTime.UtcNow.AddMinutes(double.Parse(config["Jwt:ExpiryMinutes"]!)),signingCredentials:creds);
        return Ok(new { token=new JwtSecurityTokenHandler().WriteToken(token),
            user=new { user.Id,user.Name,user.Email,user.Role } });
    }
}
