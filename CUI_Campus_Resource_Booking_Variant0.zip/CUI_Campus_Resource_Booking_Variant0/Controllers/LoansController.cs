using System.Security.Claims;
using CUIResourceBooking.Data;
using CUIResourceBooking.DTOs;
using CUIResourceBooking.Hubs;
using CUIResourceBooking.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace CUIResourceBooking.Controllers;

[ApiController, Authorize, Route("api/loans")]
public class LoansController : ControllerBase {
    private readonly AppDbContext db; private readonly IHubContext<AvailabilityHub> hub; private readonly IMemoryCache cache;
    public LoansController(AppDbContext db,IHubContext<AvailabilityHub> hub,IMemoryCache cache){this.db=db;this.hub=hub;this.cache=cache;}

    [HttpPost]
    public async Task<IActionResult> Create(CreateLoanRequest r) {
        if(r.Quantity<=0)return BadRequest(new {message="Quantity must be greater than zero."});
        var uid=int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        await using var tx=await db.Database.BeginTransactionAsync();
        var equipment=await db.Equipment.FirstOrDefaultAsync(x=>x.Id==r.EquipmentId);
        if(equipment==null)return NotFound(new {message="Equipment not found."});
        if(equipment.AvailableQuantity<r.Quantity)return Conflict(new {status=409,message="Not enough units left"});
        equipment.AvailableQuantity-=r.Quantity;
        var loan=new Loan {UserId=uid,EquipmentId=equipment.Id,Quantity=r.Quantity,Status="Pending",CreatedAt=DateTime.UtcNow};
        db.Loans.Add(loan);await db.SaveChangesAsync();await tx.CommitAsync();
        cache.Remove("equipment_catalogue");
        await Availability(equipment);
        await hub.Clients.User(uid.ToString()).SendAsync("loanupdated",new {loanId=loan.Id,status=loan.Status});
        return CreatedAtAction(nameof(GetOne),new {id=loan.Id},loan);
    }

    [HttpGet("my")]
    public async Task<IActionResult> MyLoans() {
        var uid=int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        return Ok(await db.Loans.Include(x=>x.Equipment).Where(x=>x.UserId==uid).OrderByDescending(x=>x.CreatedAt).ToListAsync());
    }
    [HttpGet,Authorize(Roles="Staff,Admin")]
    public async Task<IActionResult> GetAll() => Ok(await db.Loans.Include(x=>x.User).Include(x=>x.Equipment).OrderByDescending(x=>x.CreatedAt).ToListAsync());

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetOne(int id) {
        var loan=await db.Loans.Include(x=>x.User).Include(x=>x.Equipment).FirstOrDefaultAsync(x=>x.Id==id);
        if(loan==null)return NotFound();
        var uid=int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        if(!User.IsInRole("Staff")&&!User.IsInRole("Admin")&&loan.UserId!=uid)return Forbid();
        return Ok(loan);
    }

    [HttpPatch("{id:int}/cancel")]
    public async Task<IActionResult> Cancel(int id) {
        var loan=await db.Loans.Include(x=>x.Equipment).FirstOrDefaultAsync(x=>x.Id==id);
        if(loan==null)return NotFound();
        var uid=int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        if(!User.IsInRole("Staff")&&!User.IsInRole("Admin")&&loan.UserId!=uid)return Forbid();
        if(loan.Status=="Cancelled"||loan.Status=="Completed")return BadRequest(new {message="This loan cannot be cancelled."});
        loan.Status="Cancelled";loan.Equipment!.AvailableQuantity+=loan.Quantity;
        await db.SaveChangesAsync();cache.Remove("equipment_catalogue");await Availability(loan.Equipment);
        await hub.Clients.User(loan.UserId.ToString()).SendAsync("loanupdated",new {loanId=loan.Id,status=loan.Status});
        return Ok(new {message="Loan cancelled; quantity returned.",loan});
    }

    [HttpPatch("{id:int}/status"),Authorize(Roles="Staff,Admin")]
    public async Task<IActionResult> UpdateStatus(int id,UpdateLoanStatusRequest r) {
        var loan=await db.Loans.Include(x=>x.Equipment).FirstOrDefaultAsync(x=>x.Id==id);
        if(loan==null)return NotFound();
        var status=r.Status.Trim();
        if(status is not ("Confirmed" or "Completed" or "Cancelled"))return BadRequest(new {message="Use Confirmed, Completed or Cancelled."});
        if(loan.Status=="Cancelled"||loan.Status=="Completed")return BadRequest(new {message="Loan is already in a final state."});
        if(status=="Cancelled"){loan.Equipment!.AvailableQuantity+=loan.Quantity;cache.Remove("equipment_catalogue");}
        loan.Status=status;await db.SaveChangesAsync();
        if(status=="Cancelled")await Availability(loan.Equipment!);
        await hub.Clients.User(loan.UserId.ToString()).SendAsync("loanupdated",new {loanId=loan.Id,status=loan.Status});
        return Ok(loan);
    }
    private Task Availability(Equipment e)=>hub.Clients.All.SendAsync("availabilitychanged",new {
        equipmentId=e.Id,equipmentName=e.Name,availableQuantity=e.AvailableQuantity
    });
}
