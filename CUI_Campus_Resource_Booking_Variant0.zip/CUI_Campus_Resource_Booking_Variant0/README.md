# CUI Campus Resource Booking Service — Variant 0

Beginner-friendly ASP.NET Core 8 Web API for Lab Equipment (quantity-based) Loans.

## Requirements
- .NET 8 SDK
- Internet for the first NuGet restore

## Run
Open a terminal in this folder and run:
```bash
dotnet restore
dotnet run
```
Open the URL printed in the terminal, then visit `/swagger`.

The SQLite database `booking.db` is created automatically.

## Demo accounts
Password for all three: `Pass@123`
- Admin: `admin@cui.edu.pk`
- Staff: `staff@cui.edu.pk`
- Student: `student@cui.edu.pk`

## Main endpoints

| Method | Endpoint | Access |
|---|---|---|
| POST | `/api/auth/register` | Public; creates Student only |
| POST | `/api/auth/login` | Public |
| GET | `/api/equipment` | Logged-in users |
| GET | `/api/equipment/{id}` | Logged-in users |
| POST | `/api/equipment` | Staff/Admin |
| PUT | `/api/equipment/{id}` | Staff/Admin |
| DELETE | `/api/equipment/{id}` | Staff/Admin |
| POST | `/api/loans` | Logged-in users |
| GET | `/api/loans/my` | Own loans |
| GET | `/api/loans` | Staff/Admin |
| GET | `/api/loans/{id}` | Owner/Staff/Admin |
| PATCH | `/api/loans/{id}/cancel` | Owner/Staff/Admin |
| PATCH | `/api/loans/{id}/status` | Staff/Admin |

## Login
POST `/api/auth/login`
```json
{"email":"student@cui.edu.pk","password":"Pass@123"}
```
Copy the returned JWT. In Swagger click **Authorize**, then enter `Bearer YOUR_TOKEN`.

## Test HTTP 409
POST `/api/loans`
```json
{"equipmentId":1,"quantity":999}
```
If that quantity exceeds availability, the API returns HTTP 409 with `Not enough units left`.

## Normal loan
```json
{"equipmentId":1,"quantity":1}
```
A successful loan reduces availability. Cancelling a pending/confirmed loan returns the units.

## Staff status update
PATCH `/api/loans/1/status`
```json
{"status":"Confirmed"}
```
Allowed values: `Confirmed`, `Completed`, `Cancelled`.

## SignalR
Hub: `/hubs/availability`
- `availabilitychanged`: broadcast to all clients
- `loanupdated`: sent to the loan owner's user connection

## Caching
Equipment catalogue uses `IMemoryCache` for 60 seconds. Equipment/loan changes invalidate it. Redis is intentionally omitted to keep this classroom implementation easy to run; it can replace memory cache for a multi-server deployment.

## Important
This is an educational starter, not production-ready. Change the JWT key and demo passwords before real deployment. SQLite transaction is used for the quantity check/update.
