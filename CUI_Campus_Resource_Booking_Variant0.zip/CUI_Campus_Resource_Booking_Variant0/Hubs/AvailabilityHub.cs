using Microsoft.AspNetCore.SignalR;
namespace CUIResourceBooking.Hubs;
public class AvailabilityHub : Hub { }
