namespace CUIResourceBooking.DTOs;
public record CreateLoanRequest(int EquipmentId, int Quantity);
public record UpdateLoanStatusRequest(string Status);
