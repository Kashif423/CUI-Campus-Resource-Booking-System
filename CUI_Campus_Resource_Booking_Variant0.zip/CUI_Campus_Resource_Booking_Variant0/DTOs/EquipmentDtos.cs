namespace CUIResourceBooking.DTOs;
public record EquipmentRequest(string Name, string Description, int TotalQuantity);
