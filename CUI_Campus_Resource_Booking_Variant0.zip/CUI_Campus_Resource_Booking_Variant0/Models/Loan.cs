namespace CUIResourceBooking.Models;
public class Loan {
    public int Id { get; set; }
    public int UserId { get; set; }
    public User? User { get; set; }
    public int EquipmentId { get; set; }
    public Equipment? Equipment { get; set; }
    public int Quantity { get; set; }
    public string Status { get; set; } = "Pending";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
