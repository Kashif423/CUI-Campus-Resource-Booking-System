using System.Text;
using CUIResourceBooking.Data;
using CUIResourceBooking.Hubs;
using CUIResourceBooking.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddMemoryCache();
builder.Services.AddSignalR();
builder.Services.AddDbContext<AppDbContext>(o =>
    o.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));

var jwtKey = builder.Configuration["Jwt:Key"]!;
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true, ValidateAudience = true, ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))
    };
    options.Events = new JwtBearerEvents
    {
        OnMessageReceived = context =>
        {
            var token = context.Request.Query["access_token"];
            if (!string.IsNullOrEmpty(token) &&
                context.HttpContext.Request.Path.StartsWithSegments("/hubs/availability"))
                context.Token = token;
            return Task.CompletedTask;
        }
    };
});
builder.Services.AddAuthorization();
builder.Services.AddSwaggerGen(o =>
{
    o.SwaggerDoc("v1", new OpenApiInfo { Title = "CUI Resource Booking API", Version = "v1" });
    o.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme {
        Name = "Authorization", Type = SecuritySchemeType.Http, Scheme = "bearer",
        BearerFormat = "JWT", In = ParameterLocation.Header
    });
    o.AddSecurityRequirement(new OpenApiSecurityRequirement {
        { new OpenApiSecurityScheme {
            Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
        }, Array.Empty<string>() }
    });
});

var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();
    if (!db.Users.Any())
        db.Users.AddRange(
            new User { Name="Demo Admin", Email="admin@cui.edu.pk", PasswordHash=BCrypt.Net.BCrypt.HashPassword("Pass@123"), Role="Admin" },
            new User { Name="Demo Staff", Email="staff@cui.edu.pk", PasswordHash=BCrypt.Net.BCrypt.HashPassword("Pass@123"), Role="Staff" },
            new User { Name="Demo Student", Email="student@cui.edu.pk", PasswordHash=BCrypt.Net.BCrypt.HashPassword("Pass@123"), Role="Student" });
    if (!db.Equipment.Any())
        db.Equipment.AddRange(
            new Equipment { Name="Laptop", Description="Lab laptop", TotalQuantity=10, AvailableQuantity=10 },
            new Equipment { Name="Arduino Kit", Description="Arduino starter kit", TotalQuantity=8, AvailableQuantity=8 },
            new Equipment { Name="Projector", Description="Classroom projector", TotalQuantity=3, AvailableQuantity=3 });
    db.SaveChanges();
}
app.UseSwagger();
app.UseSwaggerUI();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapHub<AvailabilityHub>("/hubs/availability");
app.Run();
